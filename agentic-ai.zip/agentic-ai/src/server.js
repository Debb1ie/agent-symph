require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const fetch = require("node-fetch");

const app = express();
const PORT = process.env.PORT || 3000;

// Only allow localhost
app.use((req, res, next) => {
  const host = req.hostname;
  if (host !== "localhost" && host !== "127.0.0.1" && host !== "::1") {
    return res.status(403).json({ error: "Access restricted to localhost only." });
  }
  next();
});

app.use(cors({ origin: [`http://localhost:${PORT}`, `http://127.0.0.1:${PORT}`] }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// In-memory session store
const sessions = {};

// Built-in agentic tools
const TOOLS = [
  {
    name: "web_search",
    description: "Search the web for current information on a topic.",
    input_schema: {
      type: "object",
      properties: {
        query: { type: "string", description: "The search query" }
      },
      required: ["query"]
    }
  },
  {
    name: "calculator",
    description: "Perform mathematical calculations.",
    input_schema: {
      type: "object",
      properties: {
        expression: { type: "string", description: "Math expression to evaluate, e.g. '2 + 2 * 10'" }
      },
      required: ["expression"]
    }
  },
  {
    name: "get_datetime",
    description: "Get the current date and time.",
    input_schema: {
      type: "object",
      properties: {
        timezone: { type: "string", description: "Optional timezone, e.g. 'Asia/Manila'" }
      },
      required: []
    }
  },
  {
    name: "text_analyzer",
    description: "Analyze text for word count, reading time, sentiment, and key stats.",
    input_schema: {
      type: "object",
      properties: {
        text: { type: "string", description: "The text to analyze" }
      },
      required: ["text"]
    }
  },
  {
    name: "json_formatter",
    description: "Format, validate, or minify JSON data.",
    input_schema: {
      type: "object",
      properties: {
        json_string: { type: "string", description: "The JSON string to format" },
        action: { type: "string", enum: ["format", "minify", "validate"], description: "Action to perform" }
      },
      required: ["json_string", "action"]
    }
  },
  {
    name: "code_runner",
    description: "Safely evaluate simple JavaScript expressions or snippets.",
    input_schema: {
      type: "object",
      properties: {
        code: { type: "string", description: "JavaScript code to evaluate" }
      },
      required: ["code"]
    }
  }
];

// Tool execution logic
function executeTool(name, input) {
  try {
    switch (name) {
      case "calculator": {
        const safeExpr = input.expression.replace(/[^0-9+\-*/().,% ]/g, "");
        const result = Function(`"use strict"; return (${safeExpr})`)();
        return { result, expression: input.expression };
      }

      case "get_datetime": {
        const now = new Date();
        const tz = input.timezone || "UTC";
        try {
          const formatted = new Intl.DateTimeFormat("en-US", {
            timeZone: tz,
            dateStyle: "full",
            timeStyle: "long"
          }).format(now);
          return { datetime: formatted, timezone: tz, iso: now.toISOString() };
        } catch {
          return { datetime: now.toString(), timezone: "local", iso: now.toISOString() };
        }
      }

      case "text_analyzer": {
        const text = input.text;
        const words = text.trim().split(/\s+/).filter(Boolean);
        const sentences = text.split(/[.!?]+/).filter(Boolean);
        const avgWordsPerSentence = words.length / Math.max(sentences.length, 1);
        const readingTimeMin = Math.ceil(words.length / 200);
        const chars = text.length;
        const uniqueWords = new Set(words.map(w => w.toLowerCase().replace(/[^a-z]/g, ""))).size;
        return {
          word_count: words.length,
          char_count: chars,
          sentence_count: sentences.length,
          unique_words: uniqueWords,
          avg_words_per_sentence: Math.round(avgWordsPerSentence * 10) / 10,
          estimated_reading_time: `${readingTimeMin} min`
        };
      }

      case "json_formatter": {
        let parsed;
        try {
          parsed = JSON.parse(input.json_string);
        } catch (e) {
          return { error: "Invalid JSON: " + e.message };
        }
        if (input.action === "format") return { result: JSON.stringify(parsed, null, 2) };
        if (input.action === "minify") return { result: JSON.stringify(parsed) };
        if (input.action === "validate") return { valid: true, type: typeof parsed, keys: typeof parsed === "object" ? Object.keys(parsed).length : null };
        return { error: "Unknown action" };
      }

      case "code_runner": {
        // Safe sandbox: only allow simple expressions
        const forbidden = /import|require|fetch|XMLHttpRequest|process|__dirname|eval|Function|fs|child_process/;
        if (forbidden.test(input.code)) {
          return { error: "Code contains restricted keywords." };
        }
        const result = Function(`"use strict"; ${input.code}`)();
        return { result: result !== undefined ? String(result) : "undefined" };
      }

      case "web_search": {
        // Simulated search (real implementation would need a search API key)
        return {
          note: "Web search simulation — connect a real search API (e.g. Brave, Serper) for live results.",
          query: input.query,
          simulated_results: [
            { title: `Results for: "${input.query}"`, snippet: "To enable live search, add a SEARCH_API_KEY to your .env and wire it up in src/server.js." }
          ]
        };
      }

      default:
        return { error: `Unknown tool: ${name}` };
    }
  } catch (err) {
    return { error: `Tool error: ${err.message}` };
  }
}

// Agentic loop — runs up to 10 tool-call rounds
async function agenticLoop(messages, sessionId) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey || apiKey === "your_api_key_here") {
    throw new Error("ANTHROPIC_API_KEY is not configured. Edit your .env file.");
  }

  const steps = [];
  let loopMessages = [...messages];
  const MAX_ROUNDS = 10;

  for (let round = 0; round < MAX_ROUNDS; round++) {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 4096,
        system: `You are an advanced agentic AI assistant running locally on the user's machine. 
You have access to tools and use them proactively to give helpful, accurate answers.
Think step-by-step. When a task requires tools, use them. Chain multiple tools if needed.
Be concise in final answers. Always explain what tools you used and why.`,
        tools: TOOLS,
        messages: loopMessages
      })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || "API error");
    }

    const data = await response.json();
    const { content, stop_reason } = data;

    // Collect text + tool use
    const toolUses = content.filter(b => b.type === "tool_use");
    const textBlocks = content.filter(b => b.type === "text");

    steps.push({
      round: round + 1,
      text: textBlocks.map(b => b.text).join(""),
      tools_called: toolUses.map(t => ({ name: t.name, input: t.input }))
    });

    // If no tool calls or done, return final answer
    if (stop_reason === "end_turn" || toolUses.length === 0) {
      return {
        answer: textBlocks.map(b => b.text).join(""),
        steps,
        rounds: round + 1
      };
    }

    // Execute tools and build tool_result messages
    loopMessages.push({ role: "assistant", content });

    const toolResults = toolUses.map(toolUse => {
      const result = executeTool(toolUse.name, toolUse.input);
      steps[steps.length - 1].tools_called.find(t => t.name === toolUse.name).result = result;
      return {
        type: "tool_result",
        tool_use_id: toolUse.id,
        content: JSON.stringify(result)
      };
    });

    loopMessages.push({ role: "user", content: toolResults });
  }

  return { answer: "Max rounds reached.", steps, rounds: MAX_ROUNDS };
}

// === API Routes ===

// Create new session
app.post("/api/session", (req, res) => {
  const id = uuidv4();
  sessions[id] = { id, messages: [], created: Date.now() };
  res.json({ session_id: id });
});

// Send a message (agentic)
app.post("/api/chat", async (req, res) => {
  const { session_id, message } = req.body;
  if (!session_id || !sessions[session_id]) {
    return res.status(400).json({ error: "Invalid session. Create one first." });
  }
  if (!message?.trim()) {
    return res.status(400).json({ error: "Message is required." });
  }

  const session = sessions[session_id];
  session.messages.push({ role: "user", content: message });

  try {
    const result = await agenticLoop(session.messages, session_id);
    session.messages.push({ role: "assistant", content: result.answer });
    res.json({ ...result, session_id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get session history
app.get("/api/session/:id", (req, res) => {
  const session = sessions[req.params.id];
  if (!session) return res.status(404).json({ error: "Session not found." });
  res.json(session);
});

// List available tools
app.get("/api/tools", (req, res) => {
  res.json({ tools: TOOLS.map(t => ({ name: t.name, description: t.description })) });
});

// Health check
app.get("/api/health", (req, res) => {
  const hasKey = !!(process.env.ANTHROPIC_API_KEY && process.env.ANTHROPIC_API_KEY !== "your_api_key_here");
  res.json({ status: "ok", api_key_configured: hasKey, sessions: Object.keys(sessions).length });
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`\n🤖 Agentic AI running at http://localhost:${PORT}`);
  console.log(`🔒 Restricted to localhost only`);
  console.log(`📋 Tools available: ${TOOLS.map(t => t.name).join(", ")}\n`);
});
