# 🤖 Agentic AI — Local

A fully agentic AI assistant that runs **exclusively on localhost**. It uses an agentic loop — calling tools, processing results, and reasoning — to give you the best possible answers.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Configure your API key
```bash
cp .env.example .env
```
Open `.env` and set your Anthropic API key:
```
ANTHROPIC_API_KEY=sk-ant-...
```
Get a key at: https://console.anthropic.com

### 3. Start the server
```bash
npm start
```

### 4. Open in browser
Visit: **http://localhost:3000**

---

## ⚡ Built-in Tools

| Tool | Description |
|------|-------------|
| `calculator` | Safely evaluates math expressions |
| `get_datetime` | Returns current date/time with timezone support |
| `text_analyzer` | Word count, reading time, sentence stats |
| `json_formatter` | Format, minify, or validate JSON |
| `code_runner` | Runs simple JavaScript expressions safely |
| `web_search` | Placeholder — wire up a real search API |

---

## 🔒 Security

- **Localhost only** — the server rejects all connections not from `127.0.0.1`
- **CORS** restricted to localhost origin
- **Tool sandboxing** — code execution is restricted; dangerous keywords are blocked
- Your API key stays on your machine in `.env` (never sent to the frontend)

---

## 🔧 Add Real Web Search

Edit `src/server.js` — find the `web_search` case in `executeTool()` and replace with:

```javascript
case "web_search": {
  // Example using Brave Search API
  const r = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(input.query)}`, {
    headers: { 'Accept': 'application/json', 'X-Subscription-Token': process.env.BRAVE_API_KEY }
  });
  const d = await r.json();
  return { results: d.web?.results?.slice(0, 5).map(r => ({ title: r.title, url: r.url, snippet: r.description })) };
}
```

Then add `BRAVE_API_KEY=your_key` to `.env`.

---

## 📁 Structure

```
agentic-ai/
├── src/
│   └── server.js       # Express server + agentic loop
├── public/
│   └── index.html      # Frontend UI
├── .env.example        # Environment template
├── package.json
└── README.md
```

---

## 🛠 Requirements

- Node.js 18+
- An Anthropic API key
